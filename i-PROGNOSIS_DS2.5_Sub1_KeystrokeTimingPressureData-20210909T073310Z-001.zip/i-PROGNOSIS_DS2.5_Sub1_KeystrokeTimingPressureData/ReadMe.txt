﻿
Current File Version: 1.0, February, 15, 2019
Previous Version: -
Changes since last Version: - 

RELATED RESEARCH
----------------
This dataset was originally used and described in the OPEN ACCESS publication: 

[1] Iakovakis, D., Hadjidimitriou, S., Charisis, V., Bostantzopoulou, S., Katsarou, Z., & Hadjileontiadis, L. J. (2018). Touchscreen typing-pattern analysis for detecting fine motor skills decline in early-stage Parkinson’s disease. Scientific reports, 8(1), 7663. https://doi.org/10.1038/s41598-018-25999-0 

All documents and papers that report on research that uses this dataset will acknowledge this by citing the above publication.

DESCRIPTION
-----------
The dataset comprises keystroke timing and pressure data that correspond to short text excerpts typed by early Parkinson’s disease (PD) patients (n=18) and healthy controls (n=15) on a common touchscreen-equipped smartphone (LG Nexus 5X with a screen of 5.2 inches in diagonal and a resolution of 1080 × 1920 pixels, running native Android 7.0). Subjects were asked to transcribe up to 11 short text excerpts, with the initial one being 200 characters-long and common for all subjects, while the rest were 40-115 characters-long, pseudorandomly drawn from the fairy tale 'The Little Prince'. Data were recorded using a custom Android Operating System input method (keyboard), developed for the purposes of the study. Additional details on exepriment design, material and methods can be found in [1]. 

Data consist of sequences of raw press and release timestamps (in milliseconds), as well as of values of normalized pressure (0.000-1.000) applied to initiate keystrokes, corresponding to the consecutive keys tapped during the transcription of each text excerpt. Data included in the 'Data' folder are organised in sub-folders per subject. Each sub-folder contains a number of .txt files with each one corresponding to a text excerpt typed by the particular subject. Files are named using the format S##_TEX##.txt, with S## denoting the subject's coded ID and TEX## the serial number of the transcribed text excerpt. For all subjects, file S##_TEX01.txt corresponds to the initial and common 200 characters-long text excerpt. Each file contains the sequences of raw key press/release timestamps (Tp#, Tp#) and normalized pressure (NP#), applied to initiate each keystroke, in the following format:

{
Press, Tp1, Release, Tr1, NP1
Press, Tp2, Release, Tr2, NP2
.
.
.  
Press, Tpn, Release, Trn, NPn
}

where 1,2,...,n denote the serial index of the key tapped during typing.

Note: Out of 33 subjects, 32 managed to transcribe 8 to 11 text excerpts, while the remaining one (Subject ID: 16) typed only 5.  Ten subjects (Subject IDs: 6, 14, 16, 17, 25, 27, 29, 31, 32, 33) did not manage to type the initial 200 characters-long excerpt in its entirety.

The dataset also includes a record, in Microsoft Excel format (Demographics_Clinical_Characteristics.xlsx), of the demographic and clinical characteristics (with respect to PD) of subjects. Entries of the Excel file are linked to subjects' sub-folders and individual keystroke data text files via the coded ID of the subject.

Demographic characteristics included:

Age; Gender; Education level; Years of smartphone usage; Dominant hand*

Clinical characteristics included:

Group (PD, Control); Years from diagnosis; Hoehn-Yahr disease stage; Most affected side**; Levodopa Equivalent Daily Dose; UPDRS_III*** total score; UPDRS_III Item 21 Tremor-Right hand; UPDRS_III Item 21 Tremor-Left hand; UPDRS_III Item 22 Rigidity-Right hand; UPDRS_III Item 22 Rigidity-Left hand; UPDRS_III Item 23 Finger taps-Right hand; UPDRS_III Item 23 Finger taps-Left hand; UPDRS_III Item 31 Body bradykinesia/ Hypokinesia

* Dominant hand: (Relating to handedness) the operant hand generally used for performing fine motor-skills tasks.
** Most affected body side by Parkinson's disease
*** UPDRS_III: Unified Parkinson's Disease Rating Scale Part III (Motor section)

ETHICS & FUNDING
----------------
The study during which the present dataset was collected was approved by the Aristotle University of Thessaloniki Bioethics Committee of Medical School (approval no. 359/3.4.17), Thessaloniki, Greece. Informed consent, including permission for third-party access to pseudo-anonymised data, was obtained from all subjects prior to their engagement with the study. The work has received funding from the European Union's Horizon 2020 research and innovation programme under Grant Agreement No 690494 - i-PROGNOSIS: Intelligent Parkinson early detection guiding novel supportive interventions.

CORRESPONDANCE
--------------
Any inquiries regarding this dataset should be adressed to:

Mr. Dimitrios Iakovakis (Electrical & Computer Engineer, PhD candidate)

Signal Processing & Biomedical Technology Unit
Department of Electrical & Computer Engineering
Aristotle University of Thessaloniki
University Campus, Building D, 6th floor
Thessaloniki, Greece, GR54124

Tel: +30 2310 996319
Fax: +30 2310 996312
E-mail: dimiiako12@gmail.com

LICENSE
-------
This is an open access dataset, licensed under Creative Commons Attribution 4.0 International (https://creativecommons.org/licenses/by/4.0/).

WARRANTY
--------
This dataset comes without any warranty. Administrators of this dataset can not be held accountable for any damage (physical, financial or otherwise) caused by the use of this dataset.  
